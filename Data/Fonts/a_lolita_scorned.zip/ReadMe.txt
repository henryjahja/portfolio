Postcardware!
I collect postcards from all over the world.
If you like the font,please send a postcard to:

Jovana Gaspar
Baranjska 10 c
23000 Zrenjanin
Serbia

Thank you <3

Font name: A Lolita Scorned
Author: Jovana Gaspar
E-mail: angeliq@gmail.com
License - free for personal use

If you would like to use this font commercially,please contact me,licenses for commercial use are just $30 :)
Exclusive licensing is $700 and the exclusive license is still available.

Design portfolio:
http://www.jovanagaspar.com
http://www.des-gn.com

Illustration portfolio:
http://angeliq.deviantart.com

