NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
Paypal account for donation : https://paypal.me/khaiuns

Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/good-morning-14/

And follow my instagram for update: https://www.instagram.com/khaiuns/

Thank you