creator: hakee
email: hakee@hakee.org
website: blog.hakee.org

please drop me a email of your graphic work applying this font. 
thank you very much!