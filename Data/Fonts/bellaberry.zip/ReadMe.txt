ATTENTION !
By downloading, installing, copying or using a JunCreative™ Free Font product,
you agree to the terms, stated within this legal agreement:

- NOTE: This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase commercial license :
https://juncreative.net/downloads/bellaberry-lovely-script-font/

- Any donation are very appreciated
Paypal account for donation : https://www.paypal.me/MuhJunaid

- If you need a custom license please contact us at
hello@juncreative.net
or contact me to my instagram ==> https://www.instagram.com/mjart96/

-Please visit our store for more amazing fonts :
https://juncreative.net

INDONESIA - MOHON DIBACA:
Hallo, Untuk agency, designer ,youtuber atau siapa saja yang ingin menggunakan font ini untuk kebutuhan KOMERSIL seperti Film, Promo ,Logo Perusahaan ,Kaos Atau Jenis Bisnis lainnya bisa langsung membeli lisensinya di saya bisa hubungi saya di instagram cek https://www.instagram.com/mjart96/
Untuk Harga KHUSUS orang Indo sangat bersahabat kok
Terima kasih.